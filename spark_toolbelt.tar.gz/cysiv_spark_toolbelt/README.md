# spark toolbelt
This is a collection of tools that I have built up over many years.  Some are better than others.  Many are in .pyx
files to take advantage of Cython's speedups. 

## Subsections:

### utils
arrayToString(arr) : Spark UDF that converts an array field to a comma separated string.
ipInNetwork(IPv4, CIDR) : Spark  UDF returns true/false if the provided IPv4 address is in the CIDR network

quicksort(xs) : standard, recrusive quicksort implementation to sort iterable xs
    
batch(iterable, n: int = 1) : yields portions of iterable in len(n) batches.  No overlap, just splits it up 
    
window(sequence, n: int = 5) : steps through sequence and yields subset of size n (overlapping slices)

filter_blobs_to_files(blob_lists, bucket_name, customer_id=None, start_time=None, end_time=None) : sorts the blobs in the command-copy GCP bucket by customer and time.  

flatten_df(_df) : flattens a PySpark dataframe to remove nested stuct objects

flatten_and_select_non_null_cols : uses the flatten_df() function and others to drop any completely null columns from a PySpark dataframe

### stats
cramer_v(x, y) : Cramer's V coefficient - Symmetrical correlation between two categorical variables

conditional_entropy(x, y) : Calculates the conditional entropy of x given y: S(x|y)

theil_u(x, y): Theil's Uncertainty Coefficient - the uncertainty of x given y: value is on the range of [0,1] 
where 0 means y provides no information about x, and 1 means y provides full information about x

corr_ratio(categories, continuous) : Given a continuous number, how well can you know to which category it belongs to?
Value is in the range [0,1], where 0 means a category cannot be determined by a continuous measurement, and 1 means
a category can be determined with absolute certainty.


## Installation
It should pip-install. Needs to be run with a GCP Initialization Action
