import re
import json
from collections import OrderedDict
from .regular_expressions import syslog_regex_dict, kv_pairs_with_doublequote_re
from .regular_expressions import kv_pairs_with_singlequote_re, kv_pairs_without_quotes_re
from .regular_expressions import exact_re_match


def parse_meraki(message):
    results = OrderedDict({'data_source': 'cisco_meraki'})
    # Get the Stuff that is in every meraki log
    initial_parts = re.findall(syslog_regex_dict['meraki_re'], message)[0]
    results['priority'] = initial_parts[0]
    results['version'] = initial_parts[1]
    results['timestamp'] = initial_parts[2]
    results['hostname'] = initial_parts[3]
    results['app'] = initial_parts[4]
    # K-V pairs with single quotes
    for kv in re.findall(kv_pairs_with_singlequote_re, message):
        key, val = kv.split('=')
        results[key] = val.replace("'", '')
    # K-V pairs with double quotes
    for kv in re.findall(kv_pairs_with_doublequote_re, message):
        key, val = kv.split('=')
        results[key] = val.replace('"', '')
    # K-V pairs without quotes
    for kv in re.findall(kv_pairs_without_quotes_re, message):
        key, val = kv.split('=')
        results[key] = val
    results['_original_message'] = message
    return json.dumps(results)


def parse_asa(message):
    results = OrderedDict({'data_source': 'cisco_asa'})
    message_parts = re.findall(syslog_regex_dict['asa_re'], message)[0]
    results['priority'] = message_parts[0]
    results['timestamp'] = message_parts[1]
    results['hostname'] = message_parts[2]
    results['message_text'] = message_parts[3]
    results['_original_message'] = message
    return json.dumps(results)


def parse_cisco_syslog(message):
    if exact_re_match(syslog_regex_dict['meraki_re'], message):
        return parse_meraki(message)
    elif exact_re_match(syslog_regex_dict['asa_re'], message):
        return parse_asa(message)
    else:
        return None
