import re
import json
from collections import deque
from pyspark.sql import functions as f
from pyspark.sql.types import StringType, StructType, StructField
from .regular_expressions import master_time_regex, cef_regex_dict


def extract_hostname(part0):
    date_end = re.search(master_time_regex, part0).span()[1]
    cef_start = re.search(cef_regex_dict['version'], part0).span()[0]
    print(date_end, cef_start)
    return part0[date_end:cef_start].strip()


def extract_extension_pairs(extension_field_string):
    primary_queue = deque([char for char in extension_field_string])
    val_queue = deque([])
    key_queue = deque([])
    extracted_pairs = deque([])

    processing_key = False
    while len(primary_queue) > 0:
        current_char = primary_queue.pop()
        if processing_key:
            if current_char == ' ':
                extracted_pairs.appendleft((''.join(key_queue), ''.join(val_queue)))
                # Reset
                val_queue.clear()
                key_queue.clear()
                processing_key = False
            else:
                key_queue.appendleft(current_char)
        if current_char == '=':
            # switch over to processing the key
            processing_key = True
        else:
            val_queue.appendleft(current_char)

    # Check the Keys for any that are inordinately long... those ones may be vals that had an erroneous '=' char in it
    final_result = dict()

    additional_val_data = None
    while len(extracted_pairs) > 0:
        current_key, current_val = extracted_pairs.pop()
        if len(current_key) > 35:
            additional_val_data = current_key + '=' + current_val
        elif additional_val_data is not None:
            final_result[current_key] = current_val + ' ' + additional_val_data
            additional_val_data = None
        else:
            final_result[current_key] = current_val

    return final_result


def json_dump_extension(extension_data):
    return json.dumps(extract_extension_pairs(extension_data))


# Pyspark UDFs
extensionToJson = f.udf(json_dump_extension, StringType())
extractCefVer = f.udf(lambda x: x.split(' ')[-1])
extractHostname = f.udf(extract_hostname, StringType())


def parse_cef_df(df):
    split_columns = f.split(f.col('value'), "\|")
    parsed_df = df.select(f.regexp_extract(split_columns.getItem(0), cef_regex_dict['priority'], 0).alias('priority'),
                          f.regexp_extract(split_columns.getItem(0), master_time_regex, 0).alias('datetime_string'),
                          extractHostname(split_columns.getItem(0)).alias('hostname'),
                          extractCefVer(split_columns.getItem(0)).alias('cef_version'),
                          split_columns.getItem(1).alias('dvc_vendor'),
                          split_columns.getItem(2).alias('dvc_product'),
                          split_columns.getItem(3).alias('dvc_version'),
                          split_columns.getItem(4).alias('signature_id'),
                          split_columns.getItem(5).alias('name'),
                          split_columns.getItem(6).alias('severity'),
                          extensionToJson(split_columns.getItem(7)).alias('extension')
                          )

    extension_columns = parsed_df.select(f.col('extension')).rdd.map(
        lambda x: list(json.loads(x['extension']).keys())).flatMap(lambda x: x).distinct().collect()
    extension_schema = StructType([StructField(col, StringType(), True) for col in extension_columns])

    return parsed_df.withColumn('extension', f.from_json(f.col('extension'), extension_schema))
