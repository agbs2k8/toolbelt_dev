import re
from collections import OrderedDict

# This file is a collection of regular expressions to be used in parsing various logs

# Items specific for parsing CEF Logs
cef_regex_dict = OrderedDict({
    'priority': r"^.*\<[\d]*\>",
    'version': r"CEF:\d{1}"
})

# Items for ID-ing and parsing specific source syslog messages
syslog_regex_dict = OrderedDict({
    'meraki_re': r"^<(\d{3})>(\d{1}) (\d{10}\.\d{4,9}) (\w+) (\w+)(( \w+=\w+)|( \w+='.*?'))*$",
    'asa_re': r"^<(\d{3})>([a-zA-Z]{3} \d{1,2} \d{4} \d{2}:\d{2}:\d{2}): (%\w{3}-\d{1}-\d{6}): (.*)$"
})

# All of the time formats I have encountered in order of precedence for discovery
time_regex_dict = OrderedDict({
    'year_first_no_timezone': r"\d{4}[\-\/]?\d{1,2}[\-\/]?\d{1,2}[ Tt]+\d{1,2}:?\d{2}:?\d{2}",
    'year_first_with_timezone': r"\d{4}[\-\/]?\d{1,2}[\-\/]?\d{1,2}[ Tt]+\d{1,2}:?\d{2}:?\d{2}[, :\.\+Zz]+((\d{2}:\d{2})|[A-Z]{3}|\d{0,4})",
    'numeric_month_first': "\d{1,2}[\-\/]?\d{1,2}[\-\/]?\d{2,4} \d{1,2}:?\d{2}:?\d{2}([ a-zA-Z]{3})?",
    'rfc1123': r"[a-zA-Z]{3}, \d{1,2} [a-zA-Z]{3} \d{2,4} \d{2}:\d{2}:\d{2} [a-zA-Z]{3}",
    'deep_security': r"[a-zA-Z]{3} +\d{1,2} \d{1,2}:\d{1,2}:\d{1,2}",
    'epoch_float': r"\d{10}\.\d{4,9}",
    'epoch_nanoseconds': r"\d{19}",
    'epoch_microseconds': r"\d{16}",
    'epoch_milliseconds': r"\d{13}",
    'epoch_seconds': 'r"\d{10}"',
    'cisco_asa': r"^[a-zA-Z]{3} \d{1,2} \d{4} \d{2}:\d{2}:\d{2}",
    'other_junk': r"\d{2}/\w{3}/\d{4}:\d{2}:\d{2}:\d{2}"
})

# Various common data types/formats that we expect to encounter
dtype_regex_dict = OrderedDict({
    'ip': r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$",
    'ip_and_port': r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{1,5}$",
    'email': r'\w+[.|\w]\w+@\w+[.]\w+[.|\w+]\w+',
    'url': r"^[\w]+://[\w\-\.]+[\w\-\.\=\&\?/]*$",
    'windows_local_path': r"^[a-zA-Z]:\\[\w\.\\ \-]+$",
    'network_path': r"^\\[\w\.\\ \-]+$",
    'unix_path':  r"^/[\w/\- ]+$"
})

# Combine all of the time regex into a single one
master_time_regex = r''.join([r"("+x+r")|" for x in time_regex_dict.values()])[:-1]

kv_pairs_regex_dict = OrderedDict({
    'single_quotes': r"\w+='.*?'",
    'double_quotes': r'\w+=".*?"',
    'no_quotes': r'\w+=[^\s\'"]+'
})



def exact_re_match(regex, message):
    re_match = re.match(regex, message)
    if re_match is not None:
        if re_match.group() == message:
            return True
    return False
