
parsing_examples = {
    "json": "df = spark.read.json(files)",
    "cef": "df = parse_cef_df(spark.read.text(files))",
    "syslog": "spark.read.json(spark.read.text(files).rdd.map(lambda x: x['value']).map(parse_cisco_syslog).filter(lambda x: x is not None))"
}
