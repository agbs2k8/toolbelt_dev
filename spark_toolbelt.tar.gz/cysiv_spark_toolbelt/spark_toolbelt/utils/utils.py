import json
import pyspark.sql.functions as f
from pyspark.sql.types import StringType, BooleanType
from .c_utils import array_to_string, flatten, flatten_schema
from .c_ipaddresses import ip_in_network

# The Pyspark UDF
arrayToString = f.udf(array_to_string, StringType())
ipInNetwork = f.udf(ip_in_network, BooleanType())


def flatten_arrays(_df):
    for col, _dtype in _df.dtypes:
        if _dtype.startswith('array'):
            _df = _df.withColumn(col, arrayToString(_df[col]))
    return _df


def flatten_df(_df):
    column_names = flatten(flatten_schema(json.loads(_df.schema.json())))
    lowercase_used_names = set()
    final_selects = []
    merges = []
    for col in column_names:
        _rename = col.replace('.','_')
        if _rename.lower() in lowercase_used_names:
            # find the duplicate I already have:
            already_used = [x for x in final_selects if x[1].lower() == _rename.lower()][0]
            merges.append((already_used[1], _rename+'_x'))
            final_selects.append((col, _rename+'_x'))
        else:
            lowercase_used_names.add(_rename.lower())
            final_selects.append((col, _rename))
    result_df = _df.select([f.col(x[0]).alias(x[1]) for x in final_selects])

    if len(merges) > 0:
        for merge_tuple in merges:
            result_df = result_df.withColumn(merge_tuple[0], f.coalesce(f.col(merge_tuple[0]), f.col(merge_tuple[1])))
            result_df.drop(f.col(merge_tuple[1]))
    return result_df


def count_null_nan(c, dtype):
    if dtype in ['double', 'float']:
        pred = f.col(c).isNull() | f.isnan(c)
        return f.sum(pred.cast("integer")).alias(c)
    else:
        pred = f.col(c).isNull()
        return f.sum(pred.cast("integer")).alias(c)


def flatten_and_select_non_null_cols(_df):
    flat_df = flatten_df(_df)
    flat_df = flat_df.withColumn('_const', f.lit(1))
    null_counts = flat_df.agg(f.sum('_const'), *[count_null_nan(c[0], c[1]) for c in flat_df.dtypes]).rdd.collect()[0].asDict()
    count_key = 'sum(_const)'
    count = null_counts[count_key]
    good_columns = [key for key, val in null_counts.items() if key != count_key and val != count]
    return flat_df.select([f.col(x) for x in good_columns if x != '_const'])
