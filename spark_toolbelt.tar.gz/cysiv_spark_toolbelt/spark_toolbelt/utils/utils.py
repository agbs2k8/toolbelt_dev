import json
import collections
from collections.abc import Iterable
import datetime
import pyspark.sql.functions as f
from pyspark.sql.types import StringType, BooleanType
from ipaddress import ip_address, ip_network, IPv4Address, IPv4Network


def quicksort(xs):
    if not xs:
        return []
    return quicksort([x for x in xs if x < xs[0]]) + [x for x in xs if x == xs[0]] + quicksort(
        [x for x in xs if x > xs[0]])


def batch(iterable, n: int = 1):
    """
    Return a dataset in batches (no overlap)
    :param iterable: the item to be returned in segments
    :param n: length of the segments
    :return: generator of portions of the original data
    """
    for ndx in range(0, len(iterable), n):
        yield iterable[ndx:max(ndx+n, 1)]


def window(seq, n, fillvalue=None, step=1):
    """Return a sliding window of width *n* over the given iterable.

        >>> all_windows = window([1, 2, 3, 4, 5], 3)
        >>> list(all_windows)
        [(1, 2, 3), (2, 3, 4), (3, 4, 5)]

    When the window is larger than the iterable, *fillvalue* is used in place
    of missing values::

        >>> list(window([1, 2, 3], 4))
        [(1, 2, 3, None)]

    Each window will advance in increments of *step*:

        >>> list(window([1, 2, 3, 4, 5, 6], 3, fillvalue='!', step=2))
        [(1, 2, 3), (3, 4, 5), (5, 6, '!')]

    To slide into the iterable's items, use :func:`chain` to add filler items
    to the left:

        >>> iterable = [1, 2, 3, 4]
        >>> n = 3
        >>> padding = [None] * (n - 1)
        >>> list(window(itertools.chain(padding, iterable), 3))
        [(None, None, 1), (None, 1, 2), (1, 2, 3), (2, 3, 4)]

    """
    if n < 0:
        raise ValueError('n must be >= 0')
    if n == 0:
        yield tuple()
        return
    if step < 1:
        raise ValueError('step must be >= 1')

    it = iter(seq)
    window = collections.deque([], n)
    append = window.append

    # Initial deque fill
    for _ in range(n):
        append(next(it, fillvalue))
    yield tuple(window)

    # Appending new items to the right causes old items to fall off the left
    i = 0
    for item in it:
        append(item)
        i = (i + 1) % step
        if i % step == 0:
            yield tuple(window)

    # If there are items from the iterable in the window, pad with the given
    # value and emit them.
    if (i % step) and (step - i < n):
        for _ in range(step - i):
            append(fillvalue)
        yield tuple(window)


def filter_blob(blob, customer_id=None, start_time=None, end_time=None):
    time_format = '%Y%m%dT%H%M%S.%fZ'
    parsed_customer_id = blob.name.split('/')[0]
    try:
        parsed_timestamp = datetime.datetime.strptime(blob.name.split('-')[1], time_format)
    except:
        return False
    if customer_id is not None:
        if isinstance(customer_id, str):
            if customer_id != parsed_customer_id:
                return False
        elif isinstance(customer_id, list):
            if parsed_customer_id not in customer_id:
                return False
    if start_time is not None:
        if start_time >= parsed_timestamp:
            return False
    if end_time is not None:
        if end_time < parsed_timestamp:
            return False
    return True


def filter_blobs_to_files(blob_lists, bucket_name, customer_id=None, start_time=None, end_time=None):
    files = []
    for blob in blob_lists:
        if filter_blob(blob, customer_id=customer_id, start_time=start_time, end_time=end_time):
            files.append('gs://'+bucket_name+'/'+blob.name)
    return files


def iter_check(x):
    return not isinstance(x, str) and isinstance(x, Iterable)


def flatten(xs):
    result = []
    for x in xs:
        if iter_check(x):
            result += flatten(x)
        else:
            result.append(x)
    return result


def flatten_schema(field, prefix=None):
    if isinstance(field, dict) and "fields" in field.keys():
        if prefix:
            return [y for y in [flatten_schema(field['fields'][x], prefix) for x in range(len(field['fields']))] if y is not None]
        else:
            return [y for y in [flatten_schema(field['fields'][x]) for x in range(len(field['fields']))] if y is not None]
    elif isinstance(field, dict) and "type" in field.keys():
        if field['type'] in ['string', 'bigint', 'boolean', 'double', 'long']:
            if prefix:
                return prefix +'.'+ field['name']
            else:
                return field['name']
        elif field['type'] == 'array':
                return prefix
        elif field['type'] is not None:
            if prefix:
                return flatten_schema(field['type'], prefix +'.'+ field['name'])
            else:
                return flatten_schema(field['type'], field['name'])


def array_to_string(my_list):
    return '[' + ','.join([str(elem) for elem in my_list]) + ']'


def flatten_arrays(_df):
    for col, _dtype in _df.dtypes:
        if _dtype.startswith('array'):
            _df = _df.withColumn(col, arrayToString(_df[col]))
    return _df


def flatten_df(_df):
    column_names = flatten(flatten_schema(json.loads(_df.schema.json())))
    lowercase_used_names = set()
    final_selects = []
    merges = []
    for col in column_names:
        _rename = col.replace('.','_')
        if _rename.lower() in lowercase_used_names:
            # find the duplicate I already have:
            already_used = [x for x in final_selects if x[1].lower() == _rename.lower()][0]
            merges.append((already_used[1], _rename+'_x'))
            final_selects.append((col, _rename+'_x'))
        else:
            lowercase_used_names.add(_rename.lower())
            final_selects.append((col, _rename))
    result_df = _df.select([f.col(x[0]).alias(x[1]) for x in final_selects])

    if len(merges) > 0:
        for merge_tuple in merges:
            result_df = result_df.withColumn(merge_tuple[0], f.coalesce(f.col(merge_tuple[0]), f.col(merge_tuple[1])))
            result_df.drop(f.col(merge_tuple[1]))
    return result_df


def count_null_nan(c, dtype):
    if dtype in ['double', 'float']:
        pred = f.col(c).isNull() | f.isnan(c)
        return f.sum(pred.cast("integer")).alias(c)
    else:
        pred = f.col(c).isNull()
        return f.sum(pred.cast("integer")).alias(c)


def flatten_and_select_non_null_cols(_df):
    flat_df = flatten_df(_df)
    flat_df = flat_df.withColumn('_const', f.lit(1))
    null_counts = flat_df.agg(f.sum('_const'), *[count_null_nan(c[0], c[1]) for c in flat_df.dtypes]).rdd.collect()[0].asDict()
    count_key = 'sum(_const)'
    count = null_counts[count_key]
    good_columns = [key for key, val in null_counts.items() if key != count_key and val != count]
    return flat_df.select([f.col(x) for x in good_columns if x != '_const'])


def check_ip(ipaddr, error_bad_ip: bool = True) -> IPv4Address:
    """Validate provided input that it is an IPv4Address or string that can be converted to one
    :param ipaddr: either a string or IPv4Address object
    :param error_bad_ip: boolean if you want an error thrown when an invalid object is provided for the ip address
                         or only getting None returned
    :return: a valid IPv4Address obbject
    """
    if not isinstance(ipaddr, IPv4Address):
        try:
            ipaddr = ip_address(ipaddr)
            if not isinstance(ipaddr, IPv4Address):
                if error_bad_ip:
                    raise ValueError('Failed to convert the {} to a IPv4Address'.format(ipaddr))
                else:
                    print('Failed to convert the {} to a IPv4Address'.format(ipaddr))
                    return None
        except ValueError:
            if error_bad_ip:
                raise ValueError('Failed to convert the {} to a IPv4Address'.format(ipaddr))
            else:
                print('Failed to convert the {} to a IPv4Address'.format(ipaddr))
                return None
    return ipaddr


def ip_in_network(ipaddr, cidr_range):
    if not isinstance(ipaddr, IPv4Address):
        ipaddr = ip_address(ipaddr)
    if not isinstance(cidr_range, IPv4Network):
        cidr_range = ip_network(cidr_range)
    return ipaddr in cidr_range


# The Pyspark UDF
arrayToString = f.udf(array_to_string, StringType())
ipInNetwork = f.udf(ip_in_network, BooleanType())
