#!python

import math
from collections import Counter
import scipy.stats as stat
import pandas as pd
import numpy as np


def cramer_v(x: np.array, y: np.array) -> np.float:
    """
    Cramer's V coefficient - Symmetrical correlation between two categorical variables
    :param x: array
    :param y: array
    :return: float
    """
    # Count of values by each intersection of categorical features
    confusion_matrix = pd.crosstab(x, y)
    # chi2 stat for the hypothesis test of independence of the observed frequencies
    chi2 = stat.chi2_contingency(confusion_matrix)[0]
    # total # of observations
    n = confusion_matrix.sum().sum()
    phi2 = chi2 / n
    # number of unique values in x & y
    r, k = confusion_matrix.shape
    # Bias Correction (see wikipedia if needed)
    phi2corr = max(0, phi2 - ((k - 1) * (r - 1)) / (n - 1))
    rcorr = r - ((r - 1) ** 2) / (n - 1)
    kcorr = k - ((k - 1) ** 2) / (n - 1)
    # Calc & return Cramer's V correlation
    return np.sqrt(phi2corr / min((kcorr - 1), (rcorr - 1)))


def conditional_entropy(x: np.array, y: np.array) -> np.float:
    """
    Calculates the conditional entropy of x given y: S(x|y)
    :param x: array of data
    :param y: array of data
    :return: float of entropy measure
    """
    # entropy of x given y
    y_counter = Counter(y)
    xy_counter = Counter(list(zip(x, y)))
    total_occurrences = sum(y_counter.values())
    entropy = 0.0
    for xy in xy_counter.keys():
        p_xy = xy_counter[xy] / total_occurrences
        p_y = y_counter[xy[1]] / total_occurrences
        entropy += p_xy * math.log(p_y / p_xy)
    return entropy


def theil_u(x: np.array, y: np.array) -> np.float:
    """
    Theil's Uncertainty Coefficient - the uncertainty of x given y: value is on the range of [0,1] - where 0 means y
    provides no information about x, and 1 means y provides full information about x
    :param x: array
    :param y: array
    :return: float
    """
    s_xy = conditional_entropy(x, y)
    x_counter = Counter(x)
    total_occurrences = sum(x_counter.values())
    p_x = list(map(lambda n: n / total_occurrences, x_counter.values()))
    s_x = stat.entropy(p_x)
    if s_x == 0:
        return 1
    else:
        return (s_x - s_xy) / s_x


def corr_ratio(categories, continuous):
    """
    Given a continuous number, how well can you know to which category it belongs to?
    Value is in the range [0,1], where 0 means a category cannot be determined by a continuous measurement, and 1 means
    a category can be determined with absolute certainty.
    :param categories: array of categorical data
    :param continuous: array of continuous data
    :return: float
    """
    # if the input is Pandas Series, convert back to an array
    if isinstance(categories, pd.Series):
        categories = categories.values
    if isinstance(continuous, pd.Series):
        continuous = continuous.values

    fcat, _ = pd.factorize(categories)
    cat_num = np.max(fcat) + 1
    y_avg_array = np.zeros(cat_num)
    n_array = np.zeros(cat_num)
    for i in range(0, cat_num):
        cat_measures = continuous[np.argwhere(fcat == i).flatten()]
        n_array[i] = len(cat_measures)
        y_avg_array[i] = np.average(cat_measures)
    y_total_avg = np.sum(np.multiply(y_avg_array, n_array)) / np.sum(n_array)
    numerator = np.sum(np.multiply(n_array, np.power(np.subtract(y_avg_array, y_total_avg), 2)))
    denominator = np.sum(np.power(np.subtract(continuous, y_total_avg), 2))
    if numerator == 0:
        eta = 0.0
    else:
        eta = numerator / denominator
    return eta
